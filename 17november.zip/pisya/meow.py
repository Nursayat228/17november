import tkinter as tk

def add_numbers():
    try:
        number1 = float(first_entry.get())
        number2 = float(second_entry.get())
        result = number1 + number2
        result_label.config(text=f"Результат: {result}")
    except ValueError:
        result_label.config(text="Введите числа правильно")

def subtract_numbers():
    try:
        number1 = float(first_entry.get())
        number2 = float(second_entry.get())
        result = number1 - number2
        result_label.config(text=f"Результат: {result}")
    except ValueError:
        result_label.config(text="Введите числа правильно")

def multiply_numbers():
    try:
        number1 = float(first_entry.get())
        number2 = float(second_entry.get())
        result = number1 * number2
        result_label.config(text=f"Результат: {result}")
    except ValueError:
        result_label.config(text="Введите числа правильно")

def divide_numbers():
    try:
        number1 = float(first_entry.get())
        number2 = float(second_entry.get())
        if number2 == 0:
            result_label.config(text="Ошибка: деление на ноль")
        else:
            result = number1 / number2
            result_label.config(text=f"Результат: {result}")
    except ValueError:
        result_label.config(text="Введите числа правильно")

def clear_fields():
    first_entry.delete(0, tk.END)
    second_entry.delete(0, tk.END)
    result_label.config(text="Результат: ")

# Создание главного окна
window = tk.Tk()
window.title("Калькулятор")
window.geometry("400x350")
window.resizable(False, False)

# Создание контейнера Frame
main_frame = tk.Frame(window, padx=20, pady=20)
main_frame.pack(expand=True)

# Добавление заголовка
title_label = tk.Label(
    main_frame,
    text="Калькулятор",
    font=("Arial", 20, "bold")
)
title_label.grid(row=0, column=0, columnspan=2, pady=10)

# Создание полей ввода
first_label = tk.Label(main_frame, text="Первое число:")
first_label.grid(row=1, column=0, padx=5, pady=5, sticky="e")
first_entry = tk.Entry(main_frame, width=20)
first_entry.grid(row=1, column=1, padx=5, pady=5)

second_label = tk.Label(main_frame, text="Второе число:")
second_label.grid(row=2, column=0, padx=5, pady=5, sticky="e")
second_entry = tk.Entry(main_frame, width=20)
second_entry.grid(row=2, column=1, padx=5, pady=5)

# Создание кнопок арифметических операций
add_button = tk.Button(main_frame, text="Сложить", width=12, command=add_numbers)
add_button.grid(row=3, column=0, padx=5, pady=5)

subtract_button = tk.Button(main_frame, text="Вычесть", width=12, command=subtract_numbers)
subtract_button.grid(row=3, column=1, padx=5, pady=5)

multiply_button = tk.Button(main_frame, text="Умножить", width=12, command=multiply_numbers)
multiply_button.grid(row=4, column=0, padx=5, pady=5)

divide_button = tk.Button(main_frame, text="Разделить", width=12, command=divide_numbers)
divide_button.grid(row=4, column=1, padx=5, pady=5)

# Кнопка очистки
clear_button = tk.Button(main_frame, text="Очистить", width=26, command=clear_fields)
clear_button.grid(row=5, column=0, columnspan=2, pady=5)

# Вывод результата
result_label = tk.Label(
    main_frame, text="Результат: ",
    font=("Arial", 14)
)
result_label.grid(row=6, column=0, columnspan=2, pady=15)

# Запуск приложения
window.mainloop()